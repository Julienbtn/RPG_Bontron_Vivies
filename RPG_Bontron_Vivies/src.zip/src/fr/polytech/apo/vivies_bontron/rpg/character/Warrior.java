package fr.polytech.apo.vivies_bontron.rpg.character;

import fr.polytech.apo.vivies_bontron.rpg.item.Weapon;

public class Warrior extends Human {

    public Warrior(String name, int strength, int speed, int defense, int health) {
        super(name, strength, speed, defense, health);
    }
    
}
