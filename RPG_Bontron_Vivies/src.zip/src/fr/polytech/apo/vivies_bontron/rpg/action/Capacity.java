package fr.polytech.apo.vivies_bontron.rpg.action;
import fr.polytech.apo.vivies_bontron.rpg.character.Character;

public interface Capacity {

    public Effect effect(Character src, Character target);

}
