package fr.polytech.apo.vivies_bontron.rpg.character;

public enum Caracteristic {

    STRENGTH, SPEED, HEALTH, DEFENSE
}
