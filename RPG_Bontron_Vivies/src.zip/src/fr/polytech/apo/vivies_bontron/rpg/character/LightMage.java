
package fr.polytech.apo.vivies_bontron.rpg.character;


public class LightMage extends Human {
    
    public LightMage(String name, int strength, int speed, int defense, int health) {
        super(name, strength, speed, defense, health);
    }
}
